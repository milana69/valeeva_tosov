﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace фигурки
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Выберите фигуру: 1-Параллелограмм, 2-Круг");
            int choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                Console.Write("Введите сторону a:");
                double a = double.Parse(Console.ReadLine());
                Console.Write("Введите основани b:");
                double b = double.Parse(Console.ReadLine());
                Console.Write("Введите высоту h:");
                double h = double.Parse(Console.ReadLine());
                double S = b * h;
                double P = 2 * a + 2 * b;
                Console.WriteLine($"Параллелограмм: S = {S}, P = {P}");
            }
            else if (choice == 2)
            {
                Console.Write("Введите радиус: r");
                double r = double.Parse(Console.ReadLine());
                double S = Math.PI * r * r;
                double P = 2 * Math.PI * r;
                Console.WriteLine($"Круг: S = {S:F2}, P = {P:F2}");
            }
        }
    }
}
