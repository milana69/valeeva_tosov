﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.White;
            this.ClientSize = new Size(600, 450);
            this.Text = "Котек";
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            int centerX = this.ClientSize.Width / 2;
            int centerY = this.ClientSize.Height / 2;

            // 1. Туловище
            int bodyWidth = 220;
            int bodyHeight = 130;
            int bodyX = centerX - bodyWidth / 2;
            int bodyY = centerY - 30;

            g.FillEllipse(Brushes.LightGray, bodyX, bodyY, bodyWidth, bodyHeight);
            g.DrawEllipse(new Pen(Color.DarkGray, 2), bodyX, bodyY, bodyWidth, bodyHeight);

            // 2. Голова
            int headWidth = 110;
            int headHeight = 90;
            int headX = bodyX + 30;
            int headY = bodyY - 60;

            g.FillEllipse(Brushes.LightGray, headX, headY, headWidth, headHeight);
            g.DrawEllipse(new Pen(Color.DarkGray, 2), headX, headY, headWidth, headHeight);

            // 3. УШИ 
            int earHeight = 25;
            int earWidth = 15;

            // Левое ухо
            Point[] leftEar = {
                new Point(headX + 20, headY + 10),    
                new Point(headX + 40, headY + 10),      
                new Point(headX + 30, headY - earHeight)
            };

            // Правое ухо
            Point[] rightEar = {
                new Point(headX + headWidth - 40, headY + 10),
                new Point(headX + headWidth - 20, headY + 10), 
                new Point(headX + headWidth - 30, headY - earHeight) 
            };

            // Внешние уши
            g.FillPolygon(Brushes.Gray, leftEar);
            g.DrawPolygon(new Pen(Color.DarkGray, 2), leftEar);

            g.FillPolygon(Brushes.Gray, rightEar);
            g.DrawPolygon(new Pen(Color.DarkGray, 2), rightEar);

            // Внутренние уши
            Point[] leftEarInner = {
                new Point(headX + 24, headY + 12),
                new Point(headX + 36, headY + 12),
                new Point(headX + 30, headY - earHeight + 8)
            };

            Point[] rightEarInner = {
                new Point(headX + headWidth - 36, headY + 12),
                new Point(headX + headWidth - 24, headY + 12),
                new Point(headX + headWidth - 30, headY - earHeight + 8)
            };

            g.FillPolygon(Brushes.LightPink, leftEarInner);
            g.DrawPolygon(new Pen(Color.LightPink, 1), leftEarInner);

            g.FillPolygon(Brushes.LightPink, rightEarInner);
            g.DrawPolygon(new Pen(Color.LightPink, 1), rightEarInner);

            // 4. Глаза
            int eyeSize = 18;
            int eyeY = headY + 35;

            // Левый глаз
            int leftEyeX = headX + 30;
            g.FillEllipse(Brushes.GreenYellow, leftEyeX, eyeY, eyeSize, eyeSize + 5);
            g.FillEllipse(Brushes.Black, leftEyeX + 4, eyeY + 4, 10, 12);
            g.FillEllipse(Brushes.White, leftEyeX + 6, eyeY + 6, 3, 3);

            // Правый глаз
            int rightEyeX = headX + headWidth - 30 - eyeSize;
            g.FillEllipse(Brushes.GreenYellow, rightEyeX, eyeY, eyeSize, eyeSize + 5);
            g.FillEllipse(Brushes.Black, rightEyeX + 4, eyeY + 4, 10, 12);
            g.FillEllipse(Brushes.White, rightEyeX + 6, eyeY + 6, 3, 3);

            // 5. Нос
            int noseY = headY + 60;
            int noseCenterX = headX + headWidth / 2;

            Point[] nose = {
                new Point(noseCenterX - 5, noseY),
                new Point(noseCenterX + 5, noseY),
                new Point(noseCenterX, noseY + 8)
            };

            g.FillPolygon(Brushes.Pink, nose);
            g.DrawPolygon(new Pen(Color.HotPink, 1), nose);

            // 6. Усы
            Pen whiskerPen = new Pen(Color.Black, 1);
            int whiskerStartY = noseY - 5;

            // Левые усы
            g.DrawLine(whiskerPen, noseCenterX - 5, whiskerStartY, noseCenterX - 40, whiskerStartY - 10);
            g.DrawLine(whiskerPen, noseCenterX - 5, whiskerStartY + 2, noseCenterX - 40, whiskerStartY + 2);
            g.DrawLine(whiskerPen, noseCenterX - 5, whiskerStartY + 4, noseCenterX - 40, whiskerStartY + 12);

            // Правые усы
            g.DrawLine(whiskerPen, noseCenterX + 5, whiskerStartY, noseCenterX + 40, whiskerStartY - 10);
            g.DrawLine(whiskerPen, noseCenterX + 5, whiskerStartY + 2, noseCenterX + 40, whiskerStartY + 2);
            g.DrawLine(whiskerPen, noseCenterX + 5, whiskerStartY + 4, noseCenterX + 40, whiskerStartY + 12);

            // 7. Рот
            Pen mouthPen = new Pen(Color.Black, 1);
            int mouthWidth = 25;
            int mouthHeight = 10;
            int mouthX = noseCenterX - mouthWidth / 2;
            int mouthY = noseY + 5;

            g.DrawArc(mouthPen, mouthX, mouthY, mouthWidth, mouthHeight, 0, 180);

            // 8. Лапы
            int pawWidth = 45;
            int pawHeight = 25;
            int pawY = bodyY + bodyHeight - 10;

            // Левая лапа
            g.FillEllipse(Brushes.LightGray, bodyX + 40, pawY, pawWidth, pawHeight);
            g.DrawEllipse(new Pen(Color.DarkGray, 2), bodyX + 40, pawY, pawWidth, pawHeight);

            // Правая лапа
            g.FillEllipse(Brushes.LightGray, bodyX + bodyWidth - 40 - pawWidth, pawY, pawWidth, pawHeight);
            g.DrawEllipse(new Pen(Color.DarkGray, 2), bodyX + bodyWidth - 40 - pawWidth, pawY, pawWidth, pawHeight);

            // 9. Хвост
            Pen tailPen = new Pen(Color.LightGray, 12);
            tailPen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            Point[] tailPoints = {
                new Point(bodyX + bodyWidth - 10, bodyY + 40),
                new Point(bodyX + bodyWidth + 30, bodyY + 20),
                new Point(bodyX + bodyWidth + 60, bodyY + 10),
                new Point(bodyX + bodyWidth + 90, bodyY),
                new Point(bodyX + bodyWidth + 120, bodyY - 10)
            };
            g.DrawCurve(tailPen, tailPoints);

            // 10. Полоски на теле
            Pen stripePen = new Pen(Color.DarkGray, 4);
            int stripeY1 = bodyY + 30;
            int stripeY2 = bodyY + 80;

            g.DrawLine(stripePen, centerX, stripeY1, centerX, stripeY2);
            g.DrawLine(stripePen, centerX - 40, stripeY1 + 5, centerX - 40, stripeY2 - 5);
            g.DrawLine(stripePen, centerX + 40, stripeY1 + 5, centerX + 40, stripeY2 - 5);

            // 11. Щечки
            int cheekSize = 12;
            int cheekY = noseY - 10;

            g.FillEllipse(Brushes.LightPink, noseCenterX - 25, cheekY, cheekSize, cheekSize / 2);
            g.FillEllipse(Brushes.LightPink, noseCenterX + 13, cheekY, cheekSize, cheekSize / 2);

            // 12. Подпись
            Font titleFont = new Font("Arial", 14, FontStyle.Bold);
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;

            g.DrawString("Котек",
                        titleFont, Brushes.DarkBlue, centerX, 20, format);
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Invalidate();
        }
    }
}