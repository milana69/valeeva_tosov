﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace пр6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Графические примитивы";
            this.Size = new Size(800, 600);
            this.BackColor = Color.LightBlue;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Очистка фона
            g.Clear(Color.LightBlue);

            // 1. Линии (разные стили)
            DrawLines(g);

            // 2. Прямоугольники (не закрашенные)
            DrawRectangles(g);

            // 3. Закрашенные фигуры
            DrawFilledShapes(g);

            // 4. Эллипсы и круги
            DrawEllipses(g);

            // 5. Многоугольники
            DrawPolygons(g);

            // 6. Сегменты (дуги)
            DrawArcs(g);

            // 7. Текст
            DrawText(g);
        }

        private void DrawLines(Graphics g)
        {
            // Сплошная линия
            Pen solidPen = new Pen(Color.Red, 3);
            g.DrawLine(solidPen, 50, 50, 200, 50);

            // Штриховая линия
            Pen dashPen = new Pen(Color.Green, 2);
            dashPen.DashStyle = DashStyle.Dash;
            g.DrawLine(dashPen, 50, 70, 200, 70);

            // Штрих-пунктирная линия
            Pen dashDotPen = new Pen(Color.Blue, 2);
            dashDotPen.DashStyle = DashStyle.DashDot;
            g.DrawLine(dashDotPen, 50, 90, 200, 90);

            // Точки
            Pen dotPen = new Pen(Color.Purple, 2);
            dotPen.DashStyle = DashStyle.Dot;
            g.DrawLine(dotPen, 50, 110, 200, 110);

            // Освобождаем ресурсы
            solidPen.Dispose();
            dashPen.Dispose();
            dashDotPen.Dispose();
            dotPen.Dispose();
        }

        private void DrawRectangles(Graphics g)
        {
            // Простой прямоугольник
            Pen rectPen = new Pen(Color.DarkBlue, 2);
            g.DrawRectangle(rectPen, 250, 50, 150, 80);

            // Скругленный прямоугольник (через GraphicsPath)
            Pen roundRectPen = new Pen(Color.DarkGreen, 3);
            GraphicsPath path = new GraphicsPath();
            path.AddArc(420, 50, 20, 20, 180, 90);
            path.AddArc(550, 50, 20, 20, 270, 90);
            path.AddArc(550, 130, 20, 20, 0, 90);
            path.AddArc(420, 130, 20, 20, 90, 90);
            path.CloseFigure();
            g.DrawPath(roundRectPen, path);

            rectPen.Dispose();
            roundRectPen.Dispose();
            path.Dispose();
        }

        private void DrawFilledShapes(Graphics g)
        {
            // Закрашенный прямоугольник
            SolidBrush redBrush = new SolidBrush(Color.FromArgb(200, 255, 0, 0));
            g.FillRectangle(redBrush, 50, 200, 120, 80);

            // Закрашенный эллипс
            SolidBrush greenBrush = new SolidBrush(Color.FromArgb(180, 0, 255, 0));
            g.FillEllipse(greenBrush, 200, 200, 120, 80);

            // Градиентная заливка
            LinearGradientBrush gradientBrush = new LinearGradientBrush(
                new Point(350, 200),
                new Point(470, 280),
                Color.Yellow,
                Color.Orange);
            g.FillRectangle(gradientBrush, 350, 200, 120, 80);

            redBrush.Dispose();
            greenBrush.Dispose();
            gradientBrush.Dispose();
        }

        private void DrawEllipses(Graphics g)
        {
            // Эллипс
            Pen ellipsePen = new Pen(Color.DarkRed, 2);
            g.DrawEllipse(ellipsePen, 50, 300, 150, 100);

            // Круг
            Pen circlePen = new Pen(Color.DarkViolet, 3);
            g.DrawEllipse(circlePen, 250, 300, 100, 100);

            ellipsePen.Dispose();
            circlePen.Dispose();
        }

        private void DrawPolygons(Graphics g)
        {
            // Треугольник
            Point[] triangle = new Point[]
            {
                new Point(400, 350),
                new Point(500, 300),
                new Point(550, 380)
            };
            Pen trianglePen = new Pen(Color.Brown, 2);
            g.DrawPolygon(trianglePen, triangle);

            // Закрашенный шестиугольник
            Point[] hexagon = new Point[6];
            int centerX = 650;
            int centerY = 350;
            int radius = 50;

            for (int i = 0; i < 6; i++)
            {
                double angle = 2 * Math.PI * i / 6;
                hexagon[i] = new Point(
                    centerX + (int)(radius * Math.Cos(angle)),
                    centerY + (int)(radius * Math.Sin(angle))
                );
            }

            SolidBrush hexagonBrush = new SolidBrush(Color.FromArgb(150, 255, 165, 0));
            g.FillPolygon(hexagonBrush, hexagon);

            trianglePen.Dispose();
            hexagonBrush.Dispose();
        }

        private void DrawArcs(Graphics g)
        {
            // Дуга (сегмент эллипса)
            Pen arcPen = new Pen(Color.DarkCyan, 3);
            g.DrawArc(arcPen, 50, 420, 100, 80, 45, 270);

            // Закрашенный сегмент
            SolidBrush pieBrush = new SolidBrush(Color.FromArgb(180, 255, 20, 147));
            g.FillPie(pieBrush, 200, 420, 100, 80, 0, 120);

            arcPen.Dispose();
            pieBrush.Dispose();
        }

        private void DrawText(Graphics g)
        {
          
        }

        // Для перерисовки при изменении размера окна
        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Invalidate();
        }
    }
}