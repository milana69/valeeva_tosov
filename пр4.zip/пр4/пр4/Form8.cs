﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form8 : Form
    {
        private double[] A = new double[25];

        public Form8()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 25; i++)
            {
                A[i] = Math.Round(r.NextDouble() * 10 - 5, 2);
                textBox1.Text += $"A[{i}] = {A[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            int neg = 0, inRange = 0;
            for (int i = 0; i < 25; i++)
            {
                if (A[i] < 0) neg++;
                if (A[i] >= 1 && A[i] <= 2) inRange++;
            }
            textBox2.Text = $"Отрицательных: {neg}\r\nВ отрезке [1,2]: {inRange}";
        }
    }
}