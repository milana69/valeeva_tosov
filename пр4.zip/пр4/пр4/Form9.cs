﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form9 : Form
    {
        private int[] arr = new int[10];

        public Form9()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 10; i++)
            {
                arr[i] = r.Next(-20, 21);
                textBox1.Text += $"arr[{i}] = {arr[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            int product = 1;
            bool found = false;
            for (int i = 0; i < 10; i++)
            {
                if (found) product *= arr[i];
                if (arr[i] < 0 && !found) found = true;
            }

            if (!found) product = 0;
            textBox2.Text = $"Произведение после первого отрицательного: {product}";
        }
    }
}