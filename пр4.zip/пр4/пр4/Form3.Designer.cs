﻿using System.Windows.Forms;
using System;

namespace пр4
{
    partial class Form3
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox textBox1, textBox2;
        private Button btnFill, btnProcess;
        private Label label1, label2;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.textBox1 = new TextBox();
            this.textBox2 = new TextBox();
            this.btnFill = new Button();
            this.btnProcess = new Button();
            this.label1 = new Label();
            this.label2 = new Label();
            this.SuspendLayout();

            this.textBox1.Location = new System.Drawing.Point(12, 30);
            this.textBox1.Multiline = true;
            this.textBox1.Size = new System.Drawing.Size(200, 300);

            this.textBox2.Location = new System.Drawing.Point(220, 30);
            this.textBox2.Multiline = true;
            this.textBox2.Size = new System.Drawing.Size(200, 300);

            this.btnFill.Location = new System.Drawing.Point(12, 340);
            this.btnFill.Text = "Заполнить";
            this.btnFill.Click += new EventHandler(this.btnFill_Click);

            this.btnProcess.Location = new System.Drawing.Point(120, 340);
            this.btnProcess.Text = "Обменять";
            this.btnProcess.Click += new EventHandler(this.btnProcess_Click);

            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Text = "Исходный";

            this.label2.Location = new System.Drawing.Point(220, 10);
            this.label2.Text = "После обмена";

            this.ClientSize = new System.Drawing.Size(434, 381);
            this.Controls.AddRange(new Control[] {
                textBox1, textBox2, btnFill, btnProcess, label1, label2
            });
            this.Text = "Задание 2";
        }
    }
}