﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form3 : Form
    {
        private int[] arr = new int[10];

        public Form3()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 10; i++)
            {
                arr[i] = r.Next(-100, 101);
                textBox1.Text += $"arr[{i}] = {arr[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            int minIndex = 0;
            for (int i = 1; i < 10; i++)
                if (arr[i] < arr[minIndex]) minIndex = i;

            int temp = arr[9];
            arr[9] = arr[minIndex];
            arr[minIndex] = temp;

            textBox2.Text = "";
            for (int i = 0; i < 10; i++)
                textBox2.Text += $"arr[{i}] = {arr[i]}\r\n";
        }
    }
}