﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form4 : Form
    {
        private int[] R = new int[25];

        public Form4()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 25; i++)
            {
                R[i] = r.Next(-50, 51);
                textBox1.Text += $"R[{i}] = {R[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 25; i++)
            {
                if (R[i] < 0) R[i] = R[i] * R[i];
                else if (R[i] > 0) R[i] += 7;
            }

            textBox2.Text = "";
            for (int i = 0; i < 25; i++)
                textBox2.Text += $"R[{i}] = {R[i]}\r\n";
        }
    }
}