﻿namespace пр4
{
    partial class Form13
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxF = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxP = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNegative = new System.Windows.Forms.TextBox();
            this.btnFill = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();

            // label1
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(410, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "8. Вычисление массива P[i] = 0.13*F[i]^3 - 2.5*F[i+8]";

            // textBoxF
            this.textBoxF.Location = new System.Drawing.Point(6, 21);
            this.textBoxF.Multiline = true;
            this.textBoxF.Name = "textBoxF";
            this.textBoxF.ReadOnly = true;
            this.textBoxF.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxF.Size = new System.Drawing.Size(150, 250);
            this.textBoxF.TabIndex = 1;

            // label2
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Исходный массив F";

            // textBoxP
            this.textBoxP.Location = new System.Drawing.Point(6, 21);
            this.textBoxP.Multiline = true;
            this.textBoxP.Name = "textBoxP";
            this.textBoxP.ReadOnly = true;
            this.textBoxP.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxP.Size = new System.Drawing.Size(150, 250);
            this.textBoxP.TabIndex = 3;

            // label3
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Полученный массив P";

            // textBoxNegative
            this.textBoxNegative.Location = new System.Drawing.Point(6, 21);
            this.textBoxNegative.Multiline = true;
            this.textBoxNegative.Name = "textBoxNegative";
            this.textBoxNegative.ReadOnly = true;
            this.textBoxNegative.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxNegative.Size = new System.Drawing.Size(150, 250);
            this.textBoxNegative.TabIndex = 5;

            // btnFill
            this.btnFill.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnFill.Location = new System.Drawing.Point(15, 40);
            this.btnFill.Name = "btnFill";
            this.btnFill.Size = new System.Drawing.Size(150, 40);
            this.btnFill.TabIndex = 6;
            this.btnFill.Text = "Заполнить массив F";
            this.btnFill.UseVisualStyleBackColor = true;
            this.btnFill.Click += new System.EventHandler(this.btnFill_Click);

            // btnCalculate
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCalculate.Location = new System.Drawing.Point(180, 40);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(150, 40);
            this.btnCalculate.TabIndex = 7;
            this.btnCalculate.Text = "Вычислить P";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            this.btnCalculate.Enabled = false;

            // groupBox1
            this.groupBox1.Controls.Add(this.textBoxF);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(15, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(162, 280);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;

            // groupBox2
            this.groupBox2.Controls.Add(this.textBoxP);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(183, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(162, 280);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;

            // groupBox3
            this.groupBox3.Controls.Add(this.textBoxNegative);
            this.groupBox3.Location = new System.Drawing.Point(351, 100);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(162, 280);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Отрицательные элементы P";

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 400);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnFill);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Задание 8. Работа с одномерными массивами";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxF;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNegative;
        private System.Windows.Forms.Button btnFill;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}