﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form13 : Form
    {
        private double[] F = new double[18];
        private double[] P = new double[18];

        public Form13()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 18; i++)
            {
                F[i] = Math.Round(r.NextDouble() * 10 - 5, 2);
                textBox1.Text += $"F[{i}] = {F[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            textBox2.Text = "Отрицательные элементы P:\r\n";
            for (int i = 0; i < 18; i++)
            {
                P[i] = 0.13 * Math.Pow(F[i], 3) - 2.5 * F[i] + 8;
                if (P[i] < 0)
                    textBox2.Text += $"P[{i}] = {Math.Round(P[i], 2)}\r\n";
            }
        }
    }
}