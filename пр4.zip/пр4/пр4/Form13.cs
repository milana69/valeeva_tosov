﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form13 : Form
    {
        private double[] F = new double[18];
        private double[] P = new double[10]; 

        public Form13()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            
            textBoxF.Text = "";
            textBoxP.Text = "";
            textBoxNegative.Text = "";

            Random rand = new Random();

            for (int i = 0; i < 18; i++)
            {
                F[i] = Math.Round(rand.NextDouble() * 20 - 10, 2);
                textBoxF.Text += $"F[{i}] = {F[i]:F2}" + Environment.NewLine;
            }

            btnCalculate.Enabled = true;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
    
            textBoxP.Text = "";
            textBoxNegative.Text = "";


            for (int i = 0; i < 10; i++)
            {
  
                P[i] = 0.13 * Math.Pow(F[i], 3) - 2.5 * F[i + 8];


                P[i] = Math.Round(P[i], 4);

  
                textBoxP.Text += $"P[{i}] = {P[i]:F4}" + Environment.NewLine;

                if (P[i] < 0)
                {
                    textBoxNegative.Text += $"P[{i}] = {P[i]:F4}" + Environment.NewLine;
                }
            }

    
            if (string.IsNullOrEmpty(textBoxNegative.Text))
            {
                textBoxNegative.Text = "Отрицательных элементов нет";
            }
        }
    }
}