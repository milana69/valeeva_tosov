﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form2 : Form
    {
        private int[] arr = new int[20];

        public Form2()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 20; i++)
            {
                arr[i] = r.Next(-100, 101);
                textBox1.Text += $"arr[{i}] = {arr[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if (arr[0] == 0 && arr[1] == 0) return;

            int maxIndex = 0;
            for (int i = 1; i < 20; i++)
                if (arr[i] > arr[maxIndex]) maxIndex = i;

            int temp = arr[0];
            arr[0] = arr[maxIndex];
            arr[maxIndex] = temp;

            textBox2.Text = "";
            for (int i = 0; i < 20; i++)
                textBox2.Text += $"arr[{i}] = {arr[i]}\r\n";
        }
    }
}