﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form7 : Form
    {
        private int[] A = new int[30];

        public Form7()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 30; i++)
            {
                A[i] = r.Next(-100, 101);
                textBox1.Text += $"A[{i}] = {A[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            int count = 0, sum = 0;
            for (int i = 0; i < 30; i++)
            {
                if (A[i] % 5 == 0 && A[i] % 7 != 0)
                {
                    count++;
                    sum += A[i];
                }
            }
            textBox2.Text = $"Количество: {count}\r\nСумма: {sum}";
        }
    }
}