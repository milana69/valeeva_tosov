﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form12 : Form
    {
        private int[] arr = new int[15];
        private int[] result = new int[15];

        public Form12()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 15; i++)
            {
                arr[i] = r.Next(-50, 51);
                textBox1.Text += $"arr[{i}] = {arr[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 15; i++)
            {
                if (arr[i] > 0) result[i] = arr[i] * arr[i];
                else if (arr[i] < 0) result[i] = arr[i] * 2;
                else result[i] = 0;
            }

            textBox2.Text = "";
            for (int i = 0; i < 15; i++)
                textBox2.Text += $"arr[{i}] = {result[i]}\r\n";
        }
    }
}