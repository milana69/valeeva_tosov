﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр4
{
    public partial class Form10 : Form
    {
        private int[] arr = new int[14];

        public Form10()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            textBox1.Text = "";
            for (int i = 0; i < 14; i++)
            {
                arr[i] = r.Next(-20, 21);
                textBox1.Text += $"arr[{i}] = {arr[i]}\r\n";
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < 14; i++)
            {
                if (arr[i] < 0) break;
                sum += arr[i];
            }
            textBox2.Text = $"Сумма до первого отрицательного: {sum}";
        }
    }
}