﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр7
{
    public partial class Form2 : Form
    {
        private Bitmap originalBitmap;
        private Bitmap currentBitmap;
        private Graphics g;
        private Pen drawingPen;
        private bool isDrawing = false;
        private Point previousPoint;
        private Color brushColor = Color.Black;
        private int brushSize = 4;

        public Form2()
        {
            InitializeComponent();
            drawingPen = new Pen(brushColor, brushSize);
        }

        // ==================== ОСНОВНЫЕ ФУНКЦИИ ====================
        private void buttonOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tif";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                originalBitmap = new Bitmap(dialog.FileName);
                currentBitmap = new Bitmap(originalBitmap);
                pictureBox1.Image = currentBitmap;
                g = Graphics.FromImage(pictureBox1.Image);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "PNG|*.png|JPEG|*.jpg|BMP|*.bmp";
            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                currentBitmap.Save(saveDialog.FileName);
            }
        }

        // ==================== ЗАДАНИЯ ====================

        // 1. Выбор цвета и размера кисти
        private void buttonColor_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                brushColor = colorDialog.Color;
                drawingPen.Color = brushColor;
            }
        }

        private void trackBarBrush_Scroll(object sender, EventArgs e)
        {
            brushSize = trackBarBrush.Value;
            drawingPen.Width = brushSize;
            labelBrushSize.Text = $"Размер кисти: {brushSize}";
        }

        // 2. 1000 случайных точек
        private void buttonRandomPoints_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            Random rand = new Random();
            for (int i = 0; i < 1000; i++)
            {
                int x = rand.Next(currentBitmap.Width);
                int y = rand.Next(currentBitmap.Height);
                Color randomColor = Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256));
                currentBitmap.SetPixel(x, y, randomColor);
            }
            pictureBox1.Refresh();
        }

        // 3. Черно-белый (среднее)
        private void buttonGrayscale_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            for (int x = 0; x < currentBitmap.Width; x++)
            {
                for (int y = 0; y < currentBitmap.Height; y++)
                {
                    Color pixel = currentBitmap.GetPixel(x, y);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;
                    currentBitmap.SetPixel(x, y, Color.FromArgb(gray, gray, gray));
                }
            }
            pictureBox1.Refresh();
        }

        // 4. Оставить только один канал
        private void buttonRedChannel_Click(object sender, EventArgs e)
        {
            ApplyChannel(Channel.Red);
        }

        private void buttonGreenChannel_Click(object sender, EventArgs e)
        {
            ApplyChannel(Channel.Green);
        }

        private void buttonBlueChannel_Click(object sender, EventArgs e)
        {
            ApplyChannel(Channel.Blue);
        }

        private enum Channel { Red, Green, Blue }

        private void ApplyChannel(Channel channel)
        {
            if (currentBitmap == null) return;
            for (int x = 0; x < currentBitmap.Width; x++)
            {
                for (int y = 0; y < currentBitmap.Height; y++)
                {
                    Color pixel = currentBitmap.GetPixel(x, y);
                    Color newColor = Color.Black;
                    switch (channel)
                    {
                        case Channel.Red:
                            newColor = Color.FromArgb(pixel.R, 0, 0);
                            break;
                        case Channel.Green:
                            newColor = Color.FromArgb(0, pixel.G, 0);
                            break;
                        case Channel.Blue:
                            newColor = Color.FromArgb(0, 0, pixel.B);
                            break;
                    }
                    currentBitmap.SetPixel(x, y, newColor);
                }
            }
            pictureBox1.Refresh();
        }

        // 8. Горизонтальные черные линии (четные строки)
        private void buttonHorizontalLines_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            for (int y = 0; y < currentBitmap.Height; y += 2)
            {
                for (int x = 0; x < currentBitmap.Width; x++)
                {
                    currentBitmap.SetPixel(x, y, Color.Black);
                }
            }
            pictureBox1.Refresh();
        }

        // 9. Вертикальные черные линии (нечетные столбцы)
        private void buttonVerticalLines_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            for (int x = 1; x < currentBitmap.Width; x += 2)
            {
                for (int y = 0; y < currentBitmap.Height; y++)
                {
                    currentBitmap.SetPixel(x, y, Color.Black);
                }
            }
            pictureBox1.Refresh();
        }

        // 11. Замена синего на красный
        private void buttonBlueToRed_Click(object sender, EventArgs e)
        {
            
        }

        // 12. Негатив для серого
        private void buttonNegative_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            for (int x = 0; x < currentBitmap.Width; x++)
            {
                for (int y = 0; y < currentBitmap.Height; y++)
                {
                    Color pixel = currentBitmap.GetPixel(x, y);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;
                    int negative = 255 - gray;
                    currentBitmap.SetPixel(x, y, Color.FromArgb(negative, negative, negative));
                }
            }
            pictureBox1.Refresh();
        }

        // 13. Изменение яркости
        private void buttonBrightness_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            int brightness = (int)numericUpDownBrightness.Value;
            for (int x = 0; x < currentBitmap.Width; x++)
            {
                for (int y = 0; y < currentBitmap.Height; y++)
                {
                    Color pixel = currentBitmap.GetPixel(x, y);
                    int r = Clamp(pixel.R + brightness);
                    int g = Clamp(pixel.G + brightness);
                    int b = Clamp(pixel.B + brightness);
                    currentBitmap.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            pictureBox1.Refresh();
        }

        private int Clamp(int value)
        {
            return Math.Max(0, Math.Min(255, value));
        }

        // 14. Черно-белый с порогом
        private void buttonThreshold_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            int threshold = (int)numericUpDownThreshold.Value;
            for (int x = 0; x < currentBitmap.Width; x++)
            {
                for (int y = 0; y < currentBitmap.Height; y++)
                {
                    Color pixel = currentBitmap.GetPixel(x, y);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;
                    Color newColor = gray > threshold ? Color.White : Color.Black;
                    currentBitmap.SetPixel(x, y, newColor);
                }
            }
            pictureBox1.Refresh();
        }

        // 15. Эффект мозаики
        private void buttonMosaic_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            int blockSize = 10;
            for (int x = 0; x < currentBitmap.Width; x += blockSize)
            {
                for (int y = 0; y < currentBitmap.Height; y += blockSize)
                {
                    int avgR = 0, avgG = 0, avgB = 0;
                    int count = 0;
                    for (int bx = x; bx < x + blockSize && bx < currentBitmap.Width; bx++)
                    {
                        for (int by = y; by < y + blockSize && by < currentBitmap.Height; by++)
                        {
                            Color pixel = currentBitmap.GetPixel(bx, by);
                            avgR += pixel.R;
                            avgG += pixel.G;
                            avgB += pixel.B;
                            count++;
                        }
                    }
                    avgR /= count;
                    avgG /= count;
                    avgB /= count;
                    Color avgColor = Color.FromArgb(avgR, avgG, avgB);
                    for (int bx = x; bx < x + blockSize && bx < currentBitmap.Width; bx++)
                    {
                        for (int by = y; by < y + blockSize && by < currentBitmap.Height; by++)
                        {
                            currentBitmap.SetPixel(bx, by, avgColor);
                        }
                    }
                }
            }
            pictureBox1.Refresh();
        }

        // 16. Разбить на фрагменты по каналам
        private void buttonSplitChannels_Click(object sender, EventArgs e)
        {
            if (currentBitmap == null) return;
            int thirdWidth = currentBitmap.Width / 3;
            for (int x = 0; x < currentBitmap.Width; x++)
            {
                for (int y = 0; y < currentBitmap.Height; y++)
                {
                    Color pixel = currentBitmap.GetPixel(x, y);
                    Color newColor = Color.Black;
                    if (x < thirdWidth)
                        newColor = Color.FromArgb(pixel.R, 0, 0);
                    else if (x < 2 * thirdWidth)
                        newColor = Color.FromArgb(0, pixel.G, 0);
                    else
                        newColor = Color.FromArgb(0, 0, pixel.B);
                    currentBitmap.SetPixel(x, y, newColor);
                }
            }
            pictureBox1.Refresh();
        }

        // ==================== СОБЫТИЯ МЫШИ ====================
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            isDrawing = true;
            previousPoint = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing && g != null)
            {
                g.DrawLine(drawingPen, previousPoint, e.Location);
                previousPoint = e.Location;
                pictureBox1.Refresh();
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            isDrawing = false;
        }
    }
}