﻿namespace пр7
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonColor = new System.Windows.Forms.Button();
            this.trackBarBrush = new System.Windows.Forms.TrackBar();
            this.labelBrushSize = new System.Windows.Forms.Label();
            this.buttonRandomPoints = new System.Windows.Forms.Button();
            this.buttonGrayscale = new System.Windows.Forms.Button();
            this.buttonRedChannel = new System.Windows.Forms.Button();
            this.buttonGreenChannel = new System.Windows.Forms.Button();
            this.buttonBlueChannel = new System.Windows.Forms.Button();
            this.buttonHorizontalLines = new System.Windows.Forms.Button();
            this.buttonVerticalLines = new System.Windows.Forms.Button();
            this.buttonNegative = new System.Windows.Forms.Button();
            this.numericUpDownBrightness = new System.Windows.Forms.NumericUpDown();
            this.buttonBrightness = new System.Windows.Forms.Button();
            this.numericUpDownThreshold = new System.Windows.Forms.NumericUpDown();
            this.buttonThreshold = new System.Windows.Forms.Button();
            this.buttonMosaic = new System.Windows.Forms.Button();
            this.buttonSplitChannels = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBrush)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBrightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownThreshold)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 400);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // buttonOpen
            // 
            this.buttonOpen.Location = new System.Drawing.Point(618, 12);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(170, 30);
            this.buttonOpen.TabIndex = 1;
            this.buttonOpen.Text = "Открыть";
            this.buttonOpen.UseVisualStyleBackColor = true;
            this.buttonOpen.Click += new System.EventHandler(this.buttonOpen_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(618, 48);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(170, 30);
            this.buttonSave.TabIndex = 2;
            this.buttonSave.Text = "Сохранить";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonColor
            // 
            this.buttonColor.Location = new System.Drawing.Point(618, 84);
            this.buttonColor.Name = "buttonColor";
            this.buttonColor.Size = new System.Drawing.Size(170, 30);
            this.buttonColor.TabIndex = 3;
            this.buttonColor.Text = "Выбор цвета кисти";
            this.buttonColor.UseVisualStyleBackColor = true;
            this.buttonColor.Click += new System.EventHandler(this.buttonColor_Click);
            // 
            // trackBarBrush
            // 
            this.trackBarBrush.Location = new System.Drawing.Point(618, 120);
            this.trackBarBrush.Maximum = 20;
            this.trackBarBrush.Minimum = 1;
            this.trackBarBrush.Name = "trackBarBrush";
            this.trackBarBrush.Size = new System.Drawing.Size(170, 45);
            this.trackBarBrush.TabIndex = 4;
            this.trackBarBrush.Value = 4;
            this.trackBarBrush.Scroll += new System.EventHandler(this.trackBarBrush_Scroll);
            // 
            // labelBrushSize
            // 
            this.labelBrushSize.AutoSize = true;
            this.labelBrushSize.Location = new System.Drawing.Point(618, 155);
            this.labelBrushSize.Name = "labelBrushSize";
            this.labelBrushSize.Size = new System.Drawing.Size(90, 13);
            this.labelBrushSize.TabIndex = 5;
            this.labelBrushSize.Text = "Размер кисти: 4";
            // 
            // buttonRandomPoints
            // 
            this.buttonRandomPoints.Location = new System.Drawing.Point(618, 180);
            this.buttonRandomPoints.Name = "buttonRandomPoints";
            this.buttonRandomPoints.Size = new System.Drawing.Size(170, 30);
            this.buttonRandomPoints.TabIndex = 6;
            this.buttonRandomPoints.Text = "1000 случайных точек";
            this.buttonRandomPoints.UseVisualStyleBackColor = true;
            this.buttonRandomPoints.Click += new System.EventHandler(this.buttonRandomPoints_Click);
            // 
            // buttonGrayscale
            // 
            this.buttonGrayscale.Location = new System.Drawing.Point(618, 216);
            this.buttonGrayscale.Name = "buttonGrayscale";
            this.buttonGrayscale.Size = new System.Drawing.Size(170, 30);
            this.buttonGrayscale.TabIndex = 7;
            this.buttonGrayscale.Text = "Черно-белый";
            this.buttonGrayscale.UseVisualStyleBackColor = true;
            this.buttonGrayscale.Click += new System.EventHandler(this.buttonGrayscale_Click);
            // 
            // buttonRedChannel
            // 
            this.buttonRedChannel.Location = new System.Drawing.Point(618, 252);
            this.buttonRedChannel.Name = "buttonRedChannel";
            this.buttonRedChannel.Size = new System.Drawing.Size(55, 30);
            this.buttonRedChannel.TabIndex = 8;
            this.buttonRedChannel.Text = "R";
            this.buttonRedChannel.UseVisualStyleBackColor = true;
            this.buttonRedChannel.Click += new System.EventHandler(this.buttonRedChannel_Click);
            // 
            // buttonGreenChannel
            // 
            this.buttonGreenChannel.Location = new System.Drawing.Point(679, 252);
            this.buttonGreenChannel.Name = "buttonGreenChannel";
            this.buttonGreenChannel.Size = new System.Drawing.Size(55, 30);
            this.buttonGreenChannel.TabIndex = 9;
            this.buttonGreenChannel.Text = "G";
            this.buttonGreenChannel.UseVisualStyleBackColor = true;
            this.buttonGreenChannel.Click += new System.EventHandler(this.buttonGreenChannel_Click);
            // 
            // buttonBlueChannel
            // 
            this.buttonBlueChannel.Location = new System.Drawing.Point(740, 252);
            this.buttonBlueChannel.Name = "buttonBlueChannel";
            this.buttonBlueChannel.Size = new System.Drawing.Size(55, 30);
            this.buttonBlueChannel.TabIndex = 10;
            this.buttonBlueChannel.Text = "B";
            this.buttonBlueChannel.UseVisualStyleBackColor = true;
            this.buttonBlueChannel.Click += new System.EventHandler(this.buttonBlueChannel_Click);
            // 
            // buttonHorizontalLines
            // 
            this.buttonHorizontalLines.Location = new System.Drawing.Point(618, 288);
            this.buttonHorizontalLines.Name = "buttonHorizontalLines";
            this.buttonHorizontalLines.Size = new System.Drawing.Size(170, 30);
            this.buttonHorizontalLines.TabIndex = 11;
            this.buttonHorizontalLines.Text = "Горизонтальные линии";
            this.buttonHorizontalLines.UseVisualStyleBackColor = true;
            this.buttonHorizontalLines.Click += new System.EventHandler(this.buttonHorizontalLines_Click);
            // 
            // buttonVerticalLines
            // 
            this.buttonVerticalLines.Location = new System.Drawing.Point(618, 324);
            this.buttonVerticalLines.Name = "buttonVerticalLines";
            this.buttonVerticalLines.Size = new System.Drawing.Size(170, 30);
            this.buttonVerticalLines.TabIndex = 12;
            this.buttonVerticalLines.Text = "Вертикальные линии";
            this.buttonVerticalLines.UseVisualStyleBackColor = true;
            this.buttonVerticalLines.Click += new System.EventHandler(this.buttonVerticalLines_Click);
            // 
            // buttonNegative
            // 
            this.buttonNegative.Location = new System.Drawing.Point(618, 396);
            this.buttonNegative.Name = "buttonNegative";
            this.buttonNegative.Size = new System.Drawing.Size(170, 30);
            this.buttonNegative.TabIndex = 14;
            this.buttonNegative.Text = "Негатив";
            this.buttonNegative.UseVisualStyleBackColor = true;
            this.buttonNegative.Click += new System.EventHandler(this.buttonNegative_Click);
            // 
            // numericUpDownBrightness
            // 
            this.numericUpDownBrightness.Location = new System.Drawing.Point(618, 432);
            this.numericUpDownBrightness.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownBrightness.Minimum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownBrightness.Name = "numericUpDownBrightness";
            this.numericUpDownBrightness.Size = new System.Drawing.Size(80, 20);
            this.numericUpDownBrightness.TabIndex = 15;
            this.numericUpDownBrightness.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            // 
            // buttonBrightness
            // 
            this.buttonBrightness.Location = new System.Drawing.Point(704, 432);
            this.buttonBrightness.Name = "buttonBrightness";
            this.buttonBrightness.Size = new System.Drawing.Size(84, 20);
            this.buttonBrightness.TabIndex = 16;
            this.buttonBrightness.Text = "Яркость";
            this.buttonBrightness.UseVisualStyleBackColor = true;
            this.buttonBrightness.Click += new System.EventHandler(this.buttonBrightness_Click);
            // 
            // numericUpDownThreshold
            // 
            this.numericUpDownThreshold.Location = new System.Drawing.Point(618, 458);
            this.numericUpDownThreshold.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownThreshold.Name = "numericUpDownThreshold";
            this.numericUpDownThreshold.Size = new System.Drawing.Size(80, 20);
            this.numericUpDownThreshold.TabIndex = 17;
            this.numericUpDownThreshold.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            // 
            // buttonThreshold
            // 
            this.buttonThreshold.Location = new System.Drawing.Point(704, 458);
            this.buttonThreshold.Name = "buttonThreshold";
            this.buttonThreshold.Size = new System.Drawing.Size(84, 20);
            this.buttonThreshold.TabIndex = 18;
            this.buttonThreshold.Text = "Порог";
            this.buttonThreshold.UseVisualStyleBackColor = true;
            this.buttonThreshold.Click += new System.EventHandler(this.buttonThreshold_Click);
            // 
            // buttonMosaic
            // 
            this.buttonMosaic.Location = new System.Drawing.Point(618, 484);
            this.buttonMosaic.Name = "buttonMosaic";
            this.buttonMosaic.Size = new System.Drawing.Size(170, 30);
            this.buttonMosaic.TabIndex = 19;
            this.buttonMosaic.Text = "Мозаика";
            this.buttonMosaic.UseVisualStyleBackColor = true;
            this.buttonMosaic.Click += new System.EventHandler(this.buttonMosaic_Click);
            // 
            // buttonSplitChannels
            // 
            this.buttonSplitChannels.Location = new System.Drawing.Point(618, 520);
            this.buttonSplitChannels.Name = "buttonSplitChannels";
            this.buttonSplitChannels.Size = new System.Drawing.Size(170, 30);
            this.buttonSplitChannels.TabIndex = 20;
            this.buttonSplitChannels.Text = "Разбить по каналам";
            this.buttonSplitChannels.UseVisualStyleBackColor = true;
            this.buttonSplitChannels.Click += new System.EventHandler(this.buttonSplitChannels_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 560);
            this.Controls.Add(this.buttonSplitChannels);
            this.Controls.Add(this.buttonMosaic);
            this.Controls.Add(this.buttonThreshold);
            this.Controls.Add(this.numericUpDownThreshold);
            this.Controls.Add(this.buttonBrightness);
            this.Controls.Add(this.numericUpDownBrightness);
            this.Controls.Add(this.buttonNegative);
            this.Controls.Add(this.buttonVerticalLines);
            this.Controls.Add(this.buttonHorizontalLines);
            this.Controls.Add(this.buttonBlueChannel);
            this.Controls.Add(this.buttonGreenChannel);
            this.Controls.Add(this.buttonRedChannel);
            this.Controls.Add(this.buttonGrayscale);
            this.Controls.Add(this.buttonRandomPoints);
            this.Controls.Add(this.labelBrushSize);
            this.Controls.Add(this.trackBarBrush);
            this.Controls.Add(this.buttonColor);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.buttonOpen);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Графический редактор - 12 функций";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBrush)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBrightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownThreshold)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonOpen;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonColor;
        private System.Windows.Forms.TrackBar trackBarBrush;
        private System.Windows.Forms.Label labelBrushSize;
        private System.Windows.Forms.Button buttonRandomPoints;
        private System.Windows.Forms.Button buttonGrayscale;
        private System.Windows.Forms.Button buttonRedChannel;
        private System.Windows.Forms.Button buttonGreenChannel;
        private System.Windows.Forms.Button buttonBlueChannel;
        private System.Windows.Forms.Button buttonHorizontalLines;
        private System.Windows.Forms.Button buttonVerticalLines;
        private System.Windows.Forms.Button buttonNegative;
        private System.Windows.Forms.NumericUpDown numericUpDownBrightness;
        private System.Windows.Forms.Button buttonBrightness;
        private System.Windows.Forms.NumericUpDown numericUpDownThreshold;
        private System.Windows.Forms.Button buttonThreshold;
        private System.Windows.Forms.Button buttonMosaic;
        private System.Windows.Forms.Button buttonSplitChannels;
    }
}