﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form8 : Form
    {
        private int ballX = 0, ballY = 0;
        private int direction = 0;
        private const int ballSize = 40;
        private const int speed = 5;

        public Form8()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.LightGray;

            timer1.Interval = 20;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form8_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.Green, ballX, ballY, ballSize, ballSize);
            e.Graphics.DrawEllipse(Pens.DarkGreen, ballX, ballY, ballSize, ballSize);

            DrawArrow(e.Graphics);
        }

        private void DrawArrow(Graphics g)
        {
            int centerX = ballX + ballSize / 2;
            int centerY = ballY + ballSize / 2;

            Pen arrowPen = new Pen(Color.Red, 3);
            arrowPen.EndCap = LineCap.ArrowAnchor;

            switch (direction)
            {
                case 0:
                    g.DrawLine(arrowPen, centerX, centerY, centerX + 20, centerY);
                    break;
                case 1:
                    g.DrawLine(arrowPen, centerX, centerY, centerX, centerY + 20);
                    break;
                case 2:
                    g.DrawLine(arrowPen, centerX, centerY, centerX - 20, centerY);
                    break;
                case 3:
                    g.DrawLine(arrowPen, centerX, centerY, centerX, centerY - 20);
                    break;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (direction)
            {
                case 0:
                    ballX += speed;
                    if (ballX >= this.ClientSize.Width - ballSize)
                    {
                        direction = 1;
                        ballX = this.ClientSize.Width - ballSize;
                    }
                    break;
                case 1:
                    ballY += speed;
                    if (ballY >= this.ClientSize.Height - ballSize)
                    {
                        direction = 2;
                        ballY = this.ClientSize.Height - ballSize;
                    }
                    break;
                case 2:
                    ballX -= speed;
                    if (ballX <= 0)
                    {
                        direction = 3;
                        ballX = 0;
                    }
                    break;
                case 3:
                    ballY -= speed;
                    if (ballY <= 0)
                    {
                        direction = 0;
                        ballY = 0;
                    }
                    break;
            }

            this.Invalidate();
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            ballX = Math.Max(0, Math.Min(ballX, this.ClientSize.Width - ballSize));
            ballY = Math.Max(0, Math.Min(ballY, this.ClientSize.Height - ballSize));
            this.Invalidate();
        }
    }
}