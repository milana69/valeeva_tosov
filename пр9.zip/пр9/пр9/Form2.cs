﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form2 : Form
    {
        private int snowflakeY = 0;
        private int snowflakeX = 100;
        private readonly int speed = 5;
        private readonly Random rand = new Random();
        private readonly Pen snowPen = new Pen(Color.White, 3);

        public Form2()
        {
            InitializeComponent();
            this.BackColor = Color.DarkBlue;
            this.DoubleBuffered = true;

            timer1.Interval = 50;
            timer1.Tick += timer1_Tick; 
        }


        private void Form2_Load(object sender, EventArgs e)
        {
            snowflakeX = rand.Next(50, this.ClientSize.Width - 50);
        }

        // Исправляем имя на Form2_Paint
        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.White, snowflakeX, snowflakeY, 15, 15);

            // Рисуем лучи снежинки
            e.Graphics.DrawLine(snowPen, snowflakeX + 7, snowflakeY, snowflakeX + 7, snowflakeY + 15);
            e.Graphics.DrawLine(snowPen, snowflakeX, snowflakeY + 7, snowflakeX + 15, snowflakeY + 7);
            e.Graphics.DrawLine(snowPen, snowflakeX + 3, snowflakeY + 3, snowflakeX + 12, snowflakeY + 12);
            e.Graphics.DrawLine(snowPen, snowflakeX + 12, snowflakeY + 3, snowflakeX + 3, snowflakeY + 12);
        }

        // Убираем лишний пустой метод timer1_Tick_1
        private void timer1_Tick(object sender, EventArgs e)
        {
            snowflakeY += speed;

            if (snowflakeY > this.ClientSize.Height)
            {
                snowflakeY = 0;
                snowflakeX = rand.Next(50, this.ClientSize.Width - 50);
            }

            this.Invalidate();
        }
    }
}