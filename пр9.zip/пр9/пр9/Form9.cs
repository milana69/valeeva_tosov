﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form9 : Form
    {
        private class Star
        {
            public int X { get; set; }
            public int Y { get; set; }
            public int Speed { get; set; }
            public Color Color { get; set; }
            public int Size { get; set; }
        }

        private readonly List<Star> stars = new List<Star>();
        private readonly Random rand = new Random();
        private readonly Color[] starColors = { Color.Yellow, Color.White, Color.Cyan, Color.Magenta };

        public Form9()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.Black;

            for (int i = 0; i < 10; i++)
            {
                stars.Add(CreateNewStar());
            }

            timer1.Interval = 30;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private Star CreateNewStar()
        {
            return new Star
            {
                X = rand.Next(0, this.ClientSize.Width),
                Y = 0,
                Speed = rand.Next(3, 10),
                Color = starColors[rand.Next(starColors.Length)],
                Size = rand.Next(10, 25)
            };
        }

        private void Form9_Paint(object sender, PaintEventArgs e)
        {
            foreach (var star in stars)
            {
                Brush starBrush = new SolidBrush(star.Color);

                PointF[] points = new PointF[5];
                for (int i = 0; i < 5; i++)
                {
                    double angle = Math.PI * 2 * i / 5 - Math.PI / 2;
                    float radius = i % 2 == 0 ? star.Size : star.Size / 2;
                    points[i] = new PointF(
                        star.X + (float)(radius * Math.Cos(angle)),
                        star.Y + (float)(radius * Math.Sin(angle))
                    );
                }

                e.Graphics.FillPolygon(starBrush, points);
                e.Graphics.DrawPolygon(Pens.White, points);
            }

            e.Graphics.DrawString($"Звезд: {stars.Count}",
                new Font("Arial", 12), Brushes.White, 10, 10);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int i = stars.Count - 1; i >= 0; i--)
            {
                stars[i].Y += stars[i].Speed;

                if (stars[i].Y > this.ClientSize.Height)
                {
                    stars[i] = CreateNewStar();
                }
            }

            if (rand.Next(100) < 10 && stars.Count < 20)
            {
                stars.Add(CreateNewStar());
            }

            this.Invalidate();
        }
    }
}