﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form7 : Form
    {
        private int moleculeX, moleculeY;
        private readonly Random rand = new Random();
        private readonly int moleculeSize = 30;

        public Form7()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.White;

            moleculeX = this.ClientSize.Width / 2;
            moleculeY = this.ClientSize.Height / 2;
            timer1.Interval = 100;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form7_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.Blue, moleculeX - moleculeSize / 2,
                moleculeY - moleculeSize / 2, moleculeSize, moleculeSize);
            e.Graphics.DrawEllipse(Pens.DarkBlue, moleculeX - moleculeSize / 2,
                moleculeY - moleculeSize / 2, moleculeSize, moleculeSize);

            e.Graphics.FillEllipse(Brushes.Red, moleculeX - 8, moleculeY - 8, 16, 16);
            e.Graphics.DrawString("C", new Font("Arial", 8), Brushes.White,
                moleculeX - 5, moleculeY - 7);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int dx = rand.Next(-3, 4);
            int dy = rand.Next(-3, 4);

            moleculeX += dx;
            moleculeY += dy;

            moleculeX = Math.Max(moleculeSize / 2, Math.Min(this.ClientSize.Width - moleculeSize / 2, moleculeX));
            moleculeY = Math.Max(moleculeSize / 2, Math.Min(this.ClientSize.Height - moleculeSize / 2, moleculeY));

            this.Invalidate();
        }
    }
}