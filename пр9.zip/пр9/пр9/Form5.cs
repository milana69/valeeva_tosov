﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form5 : Form
    {
        private double angle = 0;
        private readonly int centerX;
        private readonly int centerY;
        private readonly double spiralStep = 0.1;

        public Form5()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.DarkBlue;
            centerX = 300;
            centerY = 200;

            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form5_Paint(object sender, PaintEventArgs e)
        {
            double radius = angle * 5;
            int x = centerX + (int)(radius * Math.Cos(angle));
            int y = centerY + (int)(radius * Math.Sin(angle));

            Pen spiralPen = new Pen(Color.Yellow, 1);
            double prevRadius = 0;
            double prevAngle = 0;

            for (double a = 0; a < angle; a += 0.1)
            {
                double r = a * 5;
                int x1 = centerX + (int)(prevRadius * Math.Cos(prevAngle));
                int y1 = centerY + (int)(prevRadius * Math.Sin(prevAngle));
                int x2 = centerX + (int)(r * Math.Cos(a));
                int y2 = centerY + (int)(r * Math.Sin(a));

                e.Graphics.DrawLine(spiralPen, x1, y1, x2, y2);
                prevRadius = r;
                prevAngle = a;
            }

            e.Graphics.FillEllipse(Brushes.Red, x - 15, y - 15, 30, 30);
            e.Graphics.DrawEllipse(Pens.White, x - 15, y - 15, 30, 30);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            angle += spiralStep;

            if (angle * 5 > Math.Min(this.ClientSize.Width, this.ClientSize.Height) / 2)
            {
                angle = 0;
            }

            this.Invalidate();
        }
    }
}