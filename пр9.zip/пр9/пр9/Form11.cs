﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form11 : Form
    {
        private int xPos = 0;
        private int step = 5;
        private int legPosition = 0;
        private int armPosition = 0;
        private bool movingRight = true;

        public Form11()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.DoubleBuffered = true;
            this.BackColor = Color.LightBlue;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            int headY = 100;
            int bodyY = headY + 30;
            int legsY = bodyY + 60;

            int headCenterX = xPos;
            int bodyCenterX = xPos;
            int armsCenterX = xPos;

            Pen blackPen = new Pen(Color.Black, 2);
            SolidBrush headBrush = new SolidBrush(Color.LightYellow);

            g.FillEllipse(headBrush, headCenterX - 15, headY, 30, 30);
            g.DrawEllipse(blackPen, headCenterX - 15, headY, 30, 30);

            g.DrawLine(blackPen, bodyCenterX, bodyY, bodyCenterX, bodyY + 60);

            int armOffset = armPosition;
            g.DrawLine(blackPen, armsCenterX - 30, bodyY + 20 - armOffset, armsCenterX, bodyY + 20);
            g.DrawLine(blackPen, armsCenterX + 30, bodyY + 20 + armOffset, armsCenterX, bodyY + 20);

            int legOffset = legPosition;
            g.DrawLine(blackPen, bodyCenterX, legsY, bodyCenterX - 20, legsY + 40 + legOffset);
            g.DrawLine(blackPen, bodyCenterX, legsY, bodyCenterX + 20, legsY + 40 - legOffset);

          

            blackPen.Dispose();
            headBrush.Dispose();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (movingRight)
            {
                xPos += step;
                if (xPos > this.ClientSize.Width - 50)
                {
                    movingRight = false;
                    step = -5;
                }
            }
            else
            {
                xPos += step;
                if (xPos < 50)
                {
                    movingRight = true;
                    step = 5;
                }
            }

            legPosition = (legPosition + 10) % 20;
            armPosition = (armPosition + 10) % 20;

            this.Invalidate();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            timer1.Start();
            buttonStart.Enabled = false;
            buttonStop.Enabled = true;
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            buttonStart.Enabled = true;
            buttonStop.Enabled = false;
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            xPos = 50;
            legPosition = 0;
            armPosition = 0;
            movingRight = true;
            step = 5;
            this.Invalidate();
        }
    }
}