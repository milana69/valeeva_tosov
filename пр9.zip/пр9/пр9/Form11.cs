﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form11 : Form
    {
        private double pulse = 1.0;
        private bool growing = true;
        private readonly int centerX;
        private readonly int centerY;
        private readonly int baseSize = 100;

        public Form11()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.Black;
            centerX = 300;
            centerY = 200;

            timer1.Interval = 100;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form11_Paint(object sender, PaintEventArgs e)
        {
            int size = (int)(baseSize * pulse);

            GraphicsPath heartPath = new GraphicsPath();

            Rectangle topLeft = new Rectangle(centerX - size / 2, centerY - size / 2, size / 2, size / 2);
            Rectangle topRight = new Rectangle(centerX, centerY - size / 2, size / 2, size / 2);

            heartPath.AddArc(topLeft, 135, 180);
            heartPath.AddArc(topRight, 225, 180);

            heartPath.AddLine(centerX - size / 2, centerY, centerX, centerY + size / 2);
            heartPath.AddLine(centerX, centerY + size / 2, centerX + size / 2, centerY);
            heartPath.CloseFigure();

            // Исправлено: ограничиваем значение красного цвета в диапазоне 0-255
            int redValue = (int)(255 * (0.5 + pulse / 2));
            redValue = Math.Max(0, Math.Min(255, redValue)); // Ограничение в диапазоне 0-255

            Color heartColor = Color.FromArgb(255, redValue, 0, 0);
            Brush heartBrush = new SolidBrush(heartColor);
            Pen heartPen = new Pen(Color.White, 3);

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.FillPath(heartBrush, heartPath);
            e.Graphics.DrawPath(heartPen, heartPath);

            e.Graphics.FillEllipse(Brushes.Pink, centerX - size / 4, centerY - size / 4, size / 6, size / 6);

            e.Graphics.DrawString($"Пульс: {pulse:F2}",
                new Font("Arial", 14), Brushes.White, 10, 10);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (growing)
            {
                pulse += 0.05;
                if (pulse >= 1.5)
                    growing = false;
            }
            else
            {
                pulse -= 0.05;
                if (pulse <= 0.7)
                    growing = true;
            }

            this.Invalidate();
        }
    }
}