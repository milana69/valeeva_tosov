﻿namespace пр9
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Timer timer1;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 50; // Устанавливаем интервал
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick); 
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 400);
            this.Name = "Form2";
            this.Text = "Падающая снежинка";
            this.Load += new System.EventHandler(this.Form2_Load); 
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form2_Paint); 
            this.ResumeLayout(false);
        }
    }
}