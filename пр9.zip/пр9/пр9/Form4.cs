﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form4 : Form
    {
        private double angle = 0;
        private int centerY;
        private readonly int amplitude = 100;
        private readonly int speed = 5;

        public Form4()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.Black;

            centerY = this.ClientSize.Height / 2;
            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form4_Paint(object sender, PaintEventArgs e)
        {
            int x = (int)(angle * 10);
            int y = centerY + (int)(amplitude * Math.Sin(angle));

            e.Graphics.FillEllipse(Brushes.Cyan, x, y, 30, 30);
            e.Graphics.DrawEllipse(Pens.White, x, y, 30, 30);

            Pen sinePen = new Pen(Color.Yellow, 2);
            for (int i = 0; i < this.ClientSize.Width - 1; i++)
            {
                int y1 = centerY + (int)(amplitude * Math.Sin(i * 0.05));
                int y2 = centerY + (int)(amplitude * Math.Sin((i + 1) * 0.05));
                e.Graphics.DrawLine(sinePen, i, y1, i + 1, y2);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            angle += 0.1;

            if (angle * 10 > this.ClientSize.Width)
            {
                angle = 0;
            }

            this.Invalidate();
        }
    }
}