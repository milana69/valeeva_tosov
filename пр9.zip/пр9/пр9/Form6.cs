﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form6 : Form
    {
        private int starX, starY;
        private int speedX, speedY;
        private readonly Random rand = new Random();
        private readonly Color[] colors = { Color.Yellow, Color.White, Color.Cyan, Color.Pink };

        public Form6()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.Black;

            starX = this.ClientSize.Width / 2;
            starY = this.ClientSize.Height / 2;
            speedX = rand.Next(-5, 6);
            speedY = rand.Next(-5, 6);
            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form6_Paint(object sender, PaintEventArgs e)
        {
            Color starColor = colors[rand.Next(colors.Length)];
            Brush starBrush = new SolidBrush(starColor);
            Pen starPen = new Pen(Color.White, 1);

            PointF[] points = new PointF[10];
            int outerRadius = 20;
            int innerRadius = 10;

            for (int i = 0; i < 5; i++)
            {
                double angle = Math.PI * 2 * i / 5 - Math.PI / 2;

                points[2 * i] = new PointF(
                    starX + (float)(outerRadius * Math.Cos(angle)),
                    starY + (float)(outerRadius * Math.Sin(angle))
                );

                points[2 * i + 1] = new PointF(
                    starX + (float)(innerRadius * Math.Cos(angle + Math.PI / 5)),
                    starY + (float)(innerRadius * Math.Sin(angle + Math.PI / 5))
                );
            }

            e.Graphics.FillPolygon(starBrush, points);
            e.Graphics.DrawPolygon(starPen, points);

            e.Graphics.FillEllipse(Brushes.Gold, starX - 5, starY - 5, 10, 10);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            starX += speedX;
            starY += speedY;

            if (starX <= 20 || starX >= this.ClientSize.Width - 20)
            {
                speedX = -speedX;
                speedX += rand.Next(-2, 3);
            }

            if (starY <= 20 || starY >= this.ClientSize.Height - 20)
            {
                speedY = -speedY;
                speedY += rand.Next(-2, 3);
            }

            if (rand.Next(100) < 10)
            {
                speedX = rand.Next(-5, 6);
                speedY = rand.Next(-5, 6);
            }

            this.Invalidate();
        }
    }
}