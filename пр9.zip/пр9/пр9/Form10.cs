﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form10 : Form
    {
        private double angle = 0;
        private readonly int centerX;
        private readonly int centerY;
        private readonly int propellerLength = 100;

        public Form10()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.SkyBlue;
            centerX = 300;
            centerY = 200;

            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form10_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.Gray, centerX - 20, centerY - 20, 40, 40);
            e.Graphics.DrawEllipse(Pens.Black, centerX - 20, centerY - 20, 40, 40);

            for (int i = 0; i < 3; i++)
            {
                double bladeAngle = angle + (i * 2 * Math.PI / 3);
                int x1 = centerX + (int)(20 * Math.Cos(bladeAngle));
                int y1 = centerY + (int)(20 * Math.Sin(bladeAngle));
                int x2 = centerX + (int)(propellerLength * Math.Cos(bladeAngle));
                int y2 = centerY + (int)(propellerLength * Math.Sin(bladeAngle));

                Pen bladePen = new Pen(Color.DarkGray, 8);
                e.Graphics.DrawLine(bladePen, x1, y1, x2, y2);
                e.Graphics.DrawLine(Pens.Black, x1, y1, x2, y2);
            }

            e.Graphics.FillRectangle(Brushes.Red, centerX - 50, centerY - 15, 100, 30);
            e.Graphics.DrawRectangle(Pens.Black, centerX - 50, centerY - 15, 100, 30);

            e.Graphics.FillRectangle(Brushes.Blue, centerX - 60, centerY - 40, 120, 15);
            e.Graphics.FillRectangle(Brushes.Blue, centerX - 60, centerY + 25, 120, 15);
            e.Graphics.FillRectangle(Brushes.Blue, centerX + 30, centerY - 25, 20, 50);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            angle += 0.3;
            this.Invalidate();
        }
    }
}