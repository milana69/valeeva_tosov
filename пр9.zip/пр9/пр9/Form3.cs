﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace пр9
{
    public partial class Form3 : Form
    {
        private int ballX = 100;
        private int ballY = 100;
        private int speedX = 5;
        private int speedY = 5;
        private const int ballSize = 40;
        private readonly Random rand = new Random();

        public Form3()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.BackColor = Color.LightGray;

            timer1.Interval = 20;
            timer1.Tick += timer1_Tick;
            timer1.Start();
        }

        private void Form3_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.Red, ballX, ballY, ballSize, ballSize);
            e.Graphics.DrawEllipse(Pens.DarkRed, ballX, ballY, ballSize, ballSize);
            e.Graphics.FillEllipse(Brushes.White, ballX + 10, ballY + 10, 10, 10);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ballX += speedX;
            ballY += speedY;

            if (ballX <= 0 || ballX >= this.ClientSize.Width - ballSize)
            {
                speedX = -speedX;
                this.BackColor = Color.FromArgb(rand.Next(150, 256),
                    rand.Next(150, 256), rand.Next(150, 256));
            }

            if (ballY <= 0 || ballY >= this.ClientSize.Height - ballSize)
            {
                speedY = -speedY;
                this.BackColor = Color.FromArgb(rand.Next(150, 256),
                    rand.Next(150, 256), rand.Next(150, 256));
            }

            this.Invalidate();
        }
    }
}