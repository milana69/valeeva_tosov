﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            string str = listBox1.SelectedItem.ToString();
            int zeros = 0, ones = 0;
            foreach (char c in str)
            {
                if (c == '0') zeros++; 
                if (c == '1') ones++;
            }
            label1.Text = $"Нулей: {zeros}, Единиц: {ones}";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            string str = listBox1.SelectedItem.ToString();
            string[] words = str.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            label1.Text = $"Количество слов: {words.Length}";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            string str = listBox1.SelectedItem.ToString();
            char[] punctuation = { '.', ',', '!', '?', ';', ':', '-'};
            int count = 0;
            foreach (char c in str)
            {
                if (punctuation.Contains(c)) count++;
            }
            label1.Text = $"Знаков препинания: {count}";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            string str = listBox1.SelectedItem.ToString();
            string digits = "";
            foreach (char c in str)
            {
                if (char.IsDigit(c)) digits += c;
            }
            label1.Text = $"Цифры в строке: {digits}";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            string str = listBox1.SelectedItem.ToString();
            string[] numbers = str.Split(',');
            int evenCount = 0;
            foreach (string num in numbers)
            {
                if (int.TryParse(num, out int n) && n % 2 == 0)
                {
                    evenCount++;
                }
            }
            label1.Text = $"Четных чисел: {evenCount}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;

            string str = listBox1.SelectedItem.ToString();
            int count = 0;

            foreach (char c in str)
            {
                if (c >= 'а' && c <= 'я' || c == 'ё')
                {
                    count++;
                }
            }

            label1.Text = $"Строчных русских букв: {count}";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;

            string str = listBox1.SelectedItem.ToString();
            string result = "";

            foreach (char c in str)
            {
                if (c >= 'а' && c <= 'я' || c == 'ё')
                {
                    result += c;
                }
            }

            label1.Text = $"Русские буквы: {result}";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;

            string str = listBox1.SelectedItem.ToString();
            string[] words = str.Split(' ');

            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 0)
                {
                    words[i] = char.ToUpper(words[i][0]) + words[i].Substring(1);
                }
            }

            label1.Text = $"Результат: {string.Join(" ", words)}";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;

            string str = listBox1.SelectedItem.ToString();
            string[] words = str.Split(' ');

            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 1)
                {
                    words[i] = words[i].Substring(1);
                }
                else if (words[i].Length == 1)
                {
                    words[i] = "";
                }
            }

            label1.Text = $"Результат: {string.Join(" ", words)}";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string str = listBox1.SelectedItem.ToString();
            char letterI = textBox1.Text[0];
            char letterJ = textBox2.Text[0];

            char[] chars = str.ToCharArray();

            for (int k = 0; k < chars.Length; k++)
            {
                if (chars[k] == letterI)
                    chars[k] = letterJ;
                else if (chars[k] == letterJ)
                    chars[k] = letterI;
            }

            label1.Text = $"{new string(chars)}";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;

            string str = listBox1.SelectedItem.ToString();
            string[] words = str.Split(' ');
            string result = "";

            foreach (string word in words)
            {
                if (word.Length > 1)
                {
                    char first = word[0];
                    char last = word[word.Length - 1];
                    string middle = word.Substring(1, word.Length - 2);
                    result += last + middle + first + " ";
                }
                else
                {
                    result += word + " ";
                }
            }

            label1.Text = $"{result.Trim()}";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;

            string str = listBox1.SelectedItem.ToString();
            string result = str.Replace('A', '*');

            label1.Text = $"{result}";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;

            string str = listBox1.SelectedItem.ToString();
            string cleanStr = str.Replace(" ", "").ToLower();

            bool isPalindrome = true;
            for (int i = 0; i < cleanStr.Length / 2; i++)
            {
                if (cleanStr[i] != cleanStr[cleanStr.Length - 1 - i])
                {
                    isPalindrome = false;
                    break;
                }
            }

            label1.Text = isPalindrome ? "Это палиндром!" : "Это не палиндром";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;

            string str = listBox1.SelectedItem.ToString();
            string result = "";

            foreach (char c in str)
            {
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
                {
                    result += '+';
                }
                else
                {
                    result += c;
                }
            }

            label1.Text = $"{result}";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;

            string str = listBox1.SelectedItem.ToString();
            string[] words = str.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string result = "";

            foreach (string word in words)
            {
                result += word.Length + " ";
            }

            label1.Text = $"{result.Trim()}";
        }
    }
}
