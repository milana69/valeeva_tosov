﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 12;
            dataGridView1.ColumnCount = 12;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] Y = new int[12, 12];
            Random rand = new Random();
            int[] columnSums = new int[12];

            for (int i = 0; i < 12; i++)
            {
                for (int j = 0; j < 12; j++)
                {
                    Y[i, j] = rand.Next(-20, 21);
                    dataGridView1.Rows[i].Cells[j].Value = Y[i, j];
                    columnSums[j] += Y[i, j];
                }
            }

            textBox1.Text = "Суммы элементов по столбцам:\r\n";
            for (int j = 0; j < 12; j++)
            {
                textBox1.Text += $"Столбец {j + 1}: {columnSums[j]}\r\n";
            }
        }
    }
}