﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 7;
            dataGridView1.ColumnCount = 7;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] F = new int[7, 7];
            Random rand = new Random();
            int[] minInColumn = new int[7];

            // Заполняем матрицу
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    F[i, j] = rand.Next(-50, 51);
                    dataGridView1.Rows[i].Cells[j].Value = F[i, j];
                }
            }

            // Инициализируем минимумы
            for (int j = 0; j < 7; j++)
            {
                minInColumn[j] = F[0, j];
            }

            // Поиск минимумов по столбцам
            for (int j = 0; j < 7; j++)
            {
                for (int i = 1; i < 7; i++)
                {
                    if (F[i, j] < minInColumn[j])
                        minInColumn[j] = F[i, j];
                }
            }

            // Вывод результатов
            textBox1.Text = "Наименьшие элементы в каждом столбце:\r\n";
            for (int j = 0; j < 7; j++)
            {
                textBox1.Text += $"Столбец {j + 1}: {minInColumn[j]}\r\n";
            }
        }
    }
}