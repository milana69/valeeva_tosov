﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 10;
            dataGridView1.ColumnCount = 10;
            dataGridView2.RowCount = 10;
            dataGridView2.ColumnCount = 10;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] A = new int[10, 10];
            Random rand = new Random();

            int max = int.MinValue;
            int maxRow = 0, maxCol = 0;

            // Заполняем и ищем максимум
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    A[i, j] = rand.Next(-100, 101);
                    dataGridView1.Rows[i].Cells[j].Value = A[i, j];

                    if (A[i, j] > max)
                    {
                        max = A[i, j];
                        maxRow = i;
                        maxCol = j;
                    }
                }
            }

            // Копируем и заменяем нулями
            int[,] B = (int[,])A.Clone();
            for (int j = 0; j < 10; j++) B[maxRow, j] = 0; // вся строка
            for (int i = 0; i < 10; i++) B[i, maxCol] = 0; // весь столбец

            // Выводим результат
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView2.Rows[i].Cells[j].Value = B[i, j];
                }
            }

            textBox1.Text = $"Наибольший элемент: {max}\r\n";
            textBox1.Text += $"Находится в [{maxRow}, {maxCol}]\r\n";
            textBox1.Text += $"Строка {maxRow + 1} и столбец {maxCol + 1} заменены нулями.";
        }
    }
}