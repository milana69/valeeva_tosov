﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] A = new int[4, 4];
            Random rand = new Random();

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    A[i, j] = rand.Next(-50, 51);
                    dataGridView1.Rows[i].Cells[j].Value = A[i, j];
                }
            }

            int maxDiag = A[0, 0];
            for (int i = 1; i < 4; i++)
            {
                if (A[i, i] > maxDiag)
                    maxDiag = A[i, i];
            }

            textBox1.Text = $"Матрица 4x4:\r\n";
            textBox1.Text += $"Наибольший элемент главной диагонали: {maxDiag}";
        }
    }
}