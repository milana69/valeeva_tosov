﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form20_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 12;
            dataGridView1.ColumnCount = 12;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] A = new int[12, 12];
            Random rand = new Random();
            int sumAbove = 0;

            for (int i = 0; i < 12; i++)
            {
                for (int j = 0; j < 12; j++)
                {
                    A[i, j] = rand.Next(-10, 11);
                    dataGridView1.Rows[i].Cells[j].Value = A[i, j];
                    if (j > i) // элементы над главной диагональю
                        sumAbove += A[i, j];
                }
            }

            textBox1.Text = $"Матрица 12x12:\r\n";
            textBox1.Text += $"Сумма элементов над главной диагональю: {sumAbove}";
        }
    }
}