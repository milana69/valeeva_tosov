﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 3;
            dataGridView1.ColumnCount = 4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] A = new int[3, 4];
            Random rand = new Random();
            int[] minInRow = new int[3];

            // Заполняем матрицу
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    A[i, j] = rand.Next(-30, 31);
                    dataGridView1.Rows[i].Cells[j].Value = A[i, j];
                }
            }

            // Находим минимумы в строках
            for (int i = 0; i < 3; i++)
            {
                minInRow[i] = A[i, 0];
                for (int j = 1; j < 4; j++)
                {
                    if (A[i, j] < minInRow[i])
                        minInRow[i] = A[i, j];
                }
            }

            // Вывод результатов
            textBox1.Text = "Наименьшие элементы в каждой строке:\r\n";
            for (int i = 0; i < 3; i++)
            {
                textBox1.Text += $"Строка {i + 1}: {minInRow[i]}\r\n";
            }
        }
    }
}