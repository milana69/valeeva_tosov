﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 10;
            dataGridView1.ColumnCount = 10;
            dataGridView2.RowCount = 10;
            dataGridView2.ColumnCount = 10;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] B = new double[10, 10];
            Random rand = new Random();

            // Исходная матрица
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    B[i, j] = rand.Next(-5, 6);
                    dataGridView1.Rows[i].Cells[j].Value = B[i, j];
                }
            }

            // Сумма главной диагонали
            double S = 0;
            for (int i = 0; i < 10; i++)
            {
                S += B[i, i];
            }

            // Преобразование
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (S > 10) B[i, j] += 13.5;
                    else if (S < 10) B[i, j] -= 1.5;
                    dataGridView2.Rows[i].Cells[j].Value = B[i, j].ToString("F2");
                }
            }

            textBox1.Text = $"Сумма диагонали S = {S:F2}\r\n";
            textBox1.Text += $"S > 10: +13.5, S < 10: -1.5\r\n";
            textBox1.Text += $"Матрица преобразована.";
        }
    }
}