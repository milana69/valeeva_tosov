﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] A = new int[4, 4];
            Random rand = new Random();
            int positiveCount = 0;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    A[i, j] = rand.Next(-20, 21);
                    dataGridView1.Rows[i].Cells[j].Value = A[i, j];
                    if (A[i, j] > 0) positiveCount++;
                }
            }

            textBox1.Text = $"Матрица 4x4:\r\n";
            textBox1.Text += $"Количество положительных элементов: {positiveCount}";
        }
    }
}