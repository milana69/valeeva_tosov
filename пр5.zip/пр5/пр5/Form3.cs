﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 3;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] A = new int[4, 3];
            Random rand = new Random();

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    A[i, j] = rand.Next(-100, 101);
                    dataGridView1.Rows[i].Cells[j].Value = A[i, j];
                }
            }

            int max = A[0, 0];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (A[i, j] > max)
                        max = A[i, j];
                }
            }

            textBox1.Text = $"Матрица 4x3:\r\n";
            textBox1.Text += $"Наибольший элемент: {max}";
        }
    }
}