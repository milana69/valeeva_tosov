﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 3;
            dataGridView1.ColumnCount = 3;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] A = new int[3, 3];
            Random rand = new Random();

            // Заполняем матрицу
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    A[i, j] = rand.Next(-10, 11);
                    dataGridView1.Rows[i].Cells[j].Value = A[i, j];
                }
            }

            // Сумма второй строки (индекс 1)
            int sumRow2 = 0;
            for (int j = 0; j < 3; j++)
            {
                sumRow2 += A[1, j];
            }

            // Произведение первого столбца (индекс 0)
            int prodCol1 = 1;
            for (int i = 0; i < 3; i++)
            {
                prodCol1 *= A[i, 0];
            }

            textBox1.Text = $"Матрица 3x3:\r\n";
            textBox1.Text += $"Сумма второй строки: {sumRow2}\r\n";
            textBox1.Text += $"Произведение первого столбца: {prodCol1}";
        }
    }
}