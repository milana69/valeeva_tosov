﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace фигурки2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);
            double h = double.Parse(textBox3.Text);

            double s_par = b * h;
            double p_par = 2 * a + 2 * b;

            double r = double.Parse(textBox4.Text);
            double s_circle = Math.PI * r * r;
            double p_circle = 2 * Math.PI * r;

            label1.Text = $"Параллелограмм: S={s_par}, P={p_par} \nКруг: S={s_circle:F2}, P={p_circle:F2}";
        }
    }
}
