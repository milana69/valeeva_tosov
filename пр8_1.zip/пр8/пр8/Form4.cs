﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBoxX.Text);
            double y = Convert.ToDouble(textBoxY.Text);
            double z = Convert.ToDouble(textBoxZ.Text);

            double f = x * x;
            double minVal = Math.Min(f, y);
            double maxVal = Math.Max(y, z);

            double result = (minVal - maxVal) / 2;
            labelResult.Text = $"p = {result:F4}";
        }
    }
}