﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBoxX.Text);
                double y = Convert.ToDouble(textBoxY.Text);

                double f = x * x; // f(x) = x^2
                double result;

                if (x * y > 0)
                {
                    result = Math.Pow(f + y, 2) - Math.Sqrt(f * y);
                }
                else if (x * y < 0)
                {
                    result = Math.Pow(f + y, 2) + Math.Sqrt(Math.Abs(f) * y);
                }
                else
                {
                    labelResult.Text = "Ошибка: xy = 0";
                    return;
                }

                labelResult.Text = $"a = {result:F4}";
            }
            catch (Exception ex)
            {
                labelResult.Text = "Ошибка ввода";
            }
        }
    }
}