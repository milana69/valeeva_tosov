﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBoxX.Text);
            double y = Convert.ToDouble(textBoxY.Text);
            double z = Convert.ToDouble(textBoxZ.Text);

            double f = x * x;
            double innerMin = Math.Min(f, y);
            double result = Math.Max(innerMin, z);

            labelResult.Text = $"r = {result:F4}";
        }
    }
}