﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBoxX.Text);
                double b = Convert.ToDouble(textBoxB.Text);

                double f = Math.Log(Math.Abs(x) + 1); // f(x) = ln(|x|+1)
                double result;

                if (0.1 * x * b < 0.5)
                {
                    result = Math.Sqrt(Math.Abs(f) + 4 * b);
                }
                else if (0.5 * x * b < 10)
                {
                    result = Math.Exp(f) - Math.Abs(b);
                }
                else
                {
                    result = b * f * f;
                }

                labelResult.Text = $"s = {result:F4}";
            }
            catch (Exception)
            {
                labelResult.Text = "Ошибка ввода";
            }
        }
    }
}