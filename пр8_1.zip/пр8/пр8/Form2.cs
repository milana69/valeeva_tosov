﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBoxX.Text);
            double y = Convert.ToDouble(textBoxY.Text);
            double z = Convert.ToDouble(textBoxZ.Text);

            double f = x * x; // f(x) = x^2
            double maxVal = Math.Max(f, Math.Max(y, z));
            double minVal = Math.Min(f, y);

            if (minVal == 0)
            {
                labelResult.Text = "Ошибка: деление на ноль";
                return;
            }

            double result = maxVal / minVal;
            labelResult.Text = $"m = {result:F4}";
        }
    }
}