﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBoxX.Text);
                double q = Convert.ToDouble(textBoxQ.Text);

                double f = Math.Cos(x); // f(x) = cos(x)
                double result;
                double xq = Math.Abs(x * q);

                if (xq > 10)
                {
                    result = Math.Log(Math.Abs(f) + Math.Abs(q));
                }
                else if (xq < 10)
                {
                    result = Math.Exp(f + q);
                }
                else // xq == 10
                {
                    result = f + q;
                }

                labelResult.Text = $"k = {result:F4}";
            }
            catch (Exception)
            {
                labelResult.Text = "Ошибка ввода";
            }
        }
    }
}