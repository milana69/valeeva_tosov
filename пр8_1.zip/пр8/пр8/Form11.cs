﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBoxX.Text);
                double a = Convert.ToDouble(textBoxA.Text);

                // Формула: a*x² + 2 / (x² + 1)²
                double numerator = a * x * x + 2;
                double denominator = Math.Pow(x * x + 1, 2);

                if (Math.Abs(denominator) < 0.000001)
                {
                    labelResult.Text = "Ошибка: деление на ноль";
                    return;
                }

                double result = numerator / denominator;
                labelResult.Text = $"a = {result:F4}";
            }
            catch (Exception)
            {
                labelResult.Text = "Ошибка ввода";
            }
        }
    }
}