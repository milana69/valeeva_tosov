﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBoxX.Text);
            double y = Convert.ToDouble(textBoxY.Text);
            double z = Convert.ToDouble(textBoxZ.Text);

            double f = x * x;
            double minVal = Math.Min(f, Math.Min(y, z));
            double maxVal = Math.Max(f, y);

            if (maxVal == 0)
            {
                labelResult.Text = "Ошибка: деление на ноль";
                return;
            }

            double result = minVal / maxVal;
            labelResult.Text = $"n = {result:F4}";
        }
    }
}