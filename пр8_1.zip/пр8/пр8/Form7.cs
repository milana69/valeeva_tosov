﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBoxX.Text);
                double y = Convert.ToDouble(textBoxY.Text);

                double f = Math.Sin(x); // f(x) = sin(x)
                double result;

                if (x - y == 0)
                {
                    result = f * f + y * y + Math.Sin(y);
                }
                else if (x - y > 0)
                {
                    result = Math.Pow(f - y, 2) + Math.Cos(y);
                }
                else
                {
                    labelResult.Text = "c = не определено";
                    return;
                }

                labelResult.Text = $"c = {result:F4}";
            }
            catch (Exception)
            {
                labelResult.Text = "Ошибка ввода";
            }
        }
    }
}