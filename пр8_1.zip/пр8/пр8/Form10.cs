﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр8
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBoxX.Text);
                int i = Convert.ToInt32(textBoxI.Text);

                double f = Math.Exp(x); // f(x) = e^x
                double result;

                if (i % 2 != 0 && x > 0)
                {
                    result = i * Math.Sqrt(f);
                }
                else if (i % 2 == 0 && x < 0)
                {
                    result = i / 2.0 * Math.Sqrt(f);
                }
                else
                {
                    labelResult.Text = "Условие не выполнено";
                    return;
                }

                labelResult.Text = $"e = {result:F4}";
            }
            catch (Exception)
            {
                labelResult.Text = "Ошибка ввода";
            }
        }
    }
}